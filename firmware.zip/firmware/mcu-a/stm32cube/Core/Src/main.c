/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  * DolphinBoi was here ;)
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <stdbool.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim3;
TIM_HandleTypeDef htim4;

UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_usart2_rx;

/* USER CODE BEGIN PV */
// Reed switch state variables (1 = closed, 0 = open)
int reed1_closed = 0;
int reed2_closed = 0;
int reed3_closed = 0;
//int reed4_closed = 0;

// Global RX buffer
uint8_t rx_byte;



// Ultrasonic distance (cm)
volatile float distance_cm = 0;

// Input capture variables
volatile uint32_t ic_val1 = 0;
volatile uint32_t ic_val2 = 0;
volatile uint8_t is_first_captured = 0;
volatile uint8_t alarm_force = 0;      // Set via UART: 1 = force ON, 0 = sensors control
float distance_threshold_cm = 10.0f;   // Object closer than this => alarm
uint32_t last_alarm_on_ms = 3000;         // For optional hold time
uint32_t alarm_auto_hold_ms = 3000;    // Keep ON for 3s after trigger (optional)

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_TIM3_Init(void);
static void MX_TIM4_Init(void);
/* USER CODE BEGIN PFP */
void UpdateReedSwitchStates(void);
void HCSR04_Trigger(void);
void SendStatusUART(void);

static void Alarm_Set(uint8_t on);
static bool IsAnyReedOpen(void);
static void ProcessAlarm(void);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART2_UART_Init();
  MX_TIM3_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */

  HAL_TIM_IC_Start_IT(&htim3, TIM_CHANNEL_1);  // Start Input Capture with interrupts
  // Start UART RX (non-DMA, interrupt-based) to read single commands
  HAL_UART_Receive_IT(&huart2, &rx_byte, 1);
  // OPTIONAL: banner so you see something in PuTTY after reset
  const char *banner = "Home-Security-System: UART online @ 115200 8-N-1\r\n";
  HAL_UART_Transmit(&huart2, (uint8_t*)banner, (uint16_t)strlen(banner), 100);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	    // Update reed switches
	    UpdateReedSwitchStates();

	    // Trigger ultrasonic ping (echo measured in TIM3 IC callback)
	    HCSR04_Trigger();

	    // Give time for the echo to arrive and the callback to compute distance_cm.
	    // 60 ms covers up to ~10 m round-trip; adjust if you expect longer distances.
	    HAL_Delay(60);

	    // Decide and drive BigSound based on sensor states and UART command
	    ProcessAlarm();

	    // Transmit one status line over UART
	    SendStatusUART();

	    // Send at ~4 Hz; adjust as needed
	    HAL_Delay(160);
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 10;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_IC_InitTypeDef sConfigIC = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 79;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_TIM_IC_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigIC.ICPolarity = TIM_INPUTCHANNELPOLARITY_RISING;
  sConfigIC.ICSelection = TIM_ICSELECTION_DIRECTTI;
  sConfigIC.ICPrescaler = TIM_ICPSC_DIV1;
  sConfigIC.ICFilter = 0;
  if (HAL_TIM_IC_ConfigChannel(&htim3, &sConfigIC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief TIM4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM4_Init(void)
{

  /* USER CODE BEGIN TIM4_Init 0 */

  /* USER CODE END TIM4_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM4_Init 1 */

  /* USER CODE END TIM4_Init 1 */
  htim4.Instance = TIM4;
  htim4.Init.Prescaler = 79;
  htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim4.Init.Period = 499;
  htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim4.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim4) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim4, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim4, &sConfigOC, TIM_CHANNEL_1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM4_Init 2 */

  /* USER CODE END TIM4_Init 2 */
  HAL_TIM_MspPostInit(&htim4);


    HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1);
}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Channel6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Channel6_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Channel6_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD2_Pin|TriggerUltra_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : LD2_Pin TriggerUltra_Pin */
  GPIO_InitStruct.Pin = LD2_Pin|TriggerUltra_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : Reed3_Pin Reed2_Pin Reed1_Pin */
  GPIO_InitStruct.Pin = Reed3_Pin|Reed2_Pin|Reed1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

// BigSound is active-high: SET = ON, RESET = OFF.
// If your hardware is active-low, invert the pin levels here.
static void Alarm_Set(uint8_t on)
{
    // Drive PWM duty instead of GPIO. When ON: ~50% duty; OFF: 0% duty.
    uint32_t arr = __HAL_TIM_GET_AUTORELOAD(&htim4);
    uint32_t half = (arr + 1U) / 2U;
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, on ? half : 0U);
}
static bool IsAnyReedOpen(void)
{
  // Your code defines reedX_closed = 1 when GPIO is SET (closed), 0 when open.
  // Alarm if ANY reed is open.
  return (!reed1_closed) || (!reed2_closed) || (!reed3_closed);
}

static void ProcessAlarm(void)
{
  uint32_t now = HAL_GetTick();

  // Sensor-based trigger:
  // - any reed open
  // - object closer than threshold (ignore bogus 0 distance)
  bool sensor_trigger =
      IsAnyReedOpen() ||
      ((distance_cm > 0.0f) && (distance_cm <= distance_threshold_cm));

  // Final decision: sensors OR forced-on via UART
  bool alarm_on = sensor_trigger || (alarm_force != 0);

  if (alarm_on)
  {
    Alarm_Set(1);
    last_alarm_on_ms = now; // remember when it turned on
  }
  else
  {
    // Optional "hold" so the alarm stays on briefly after the trigger clears
    if (alarm_auto_hold_ms == 0 || (now - last_alarm_on_ms) >= alarm_auto_hold_ms)
    {
      Alarm_Set(0);
    }
  }
}

// UART receive: simple command parser
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART2)
  {
    switch (rx_byte)
    {
      case 'A': case 'a':   // Force alarm ON
      case '1': case '!':
        alarm_force = 1;
        break;

      case 'C': case 'c':   // Clear forced alarm (back to sensor-driven)
      case '0': case '.':
        alarm_force = 0;
        break;

      // Optional: change threshold on the fly (examples)
      case '+':  // increase threshold by 5 cm
        distance_threshold_cm += 5.0f;
        break;
      case '-':  // decrease threshold by 5 cm (min 5 cm)
        if (distance_threshold_cm > 5.0f) distance_threshold_cm -= 5.0f;
        break;

      default:
        break;
    }

    // Re-arm RX for next byte
    HAL_UART_Receive_IT(&huart2, &rx_byte, 1);
  }
}
static inline char oc(int closed) { return closed ? 'C' : 'O'; } // C=Closed, O=Open

void SendStatusUART(void)
{
  char tx_buf[128];

  // Compose: which reed is open/closed + current distance (cm)
  // Example: "R1:C R2:O R3:O R4:C | Dist: 23.5 cm\r\n"
  int n = snprintf(tx_buf, sizeof(tx_buf), "R1:%c R2:%c R3:%c | Dist: %.1f cm\r\n", oc(reed1_closed), oc(reed2_closed), oc(reed3_closed), distance_cm);
  if (n > 0)
  {
    HAL_UART_Transmit(&huart2, (uint8_t*)tx_buf, (uint16_t)n, 50); // blocking TX
  }
}

void HCSR04_Trigger(void)
{
    HAL_GPIO_WritePin(TriggerUltra_GPIO_Port, TriggerUltra_Pin, GPIO_PIN_SET);

    // ~10 µs delay
    for (volatile int i = 0; i < 100; i++)
        __NOP();

    HAL_GPIO_WritePin(TriggerUltra_GPIO_Port, TriggerUltra_Pin, GPIO_PIN_RESET);
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
    if (htim->Instance == TIM3 && htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1)
    {
        if (is_first_captured == 0)
        {
            ic_val1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
            is_first_captured = 1;
            __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_FALLING);
        }
        else
        {
            ic_val2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);

            uint32_t diff;
            if (ic_val2 >= ic_val1)
                diff = ic_val2 - ic_val1;
            else
                diff = (htim->Instance->ARR - ic_val1) + ic_val2 + 1;

            distance_cm = (float)diff * 0.0343f / 2.0f;

            is_first_captured = 0;
            __HAL_TIM_SET_CAPTUREPOLARITY(htim, TIM_CHANNEL_1, TIM_INPUTCHANNELPOLARITY_RISING);
        }
    }
}

void UpdateReedSwitchStates(void)
{
    reed1_closed = (HAL_GPIO_ReadPin(Reed1_GPIO_Port, Reed1_Pin) == GPIO_PIN_SET) ? 1 : 0;
    reed2_closed = (HAL_GPIO_ReadPin(Reed2_GPIO_Port, Reed2_Pin) == GPIO_PIN_SET) ? 1 : 0;
    reed3_closed = (HAL_GPIO_ReadPin(Reed3_GPIO_Port, Reed3_Pin) == GPIO_PIN_SET) ? 1 : 0;
    reed4_closed = (HAL_GPIO_ReadPin(Reed4_GPIO_Port, Reed4_Pin) == GPIO_PIN_SET) ? 1 : 0;
}


static void BigSound_SelfTest_GPIO(void)
{
  // Fall-back self-test: drive PB6 (BigSound) as plain GPIO to generate a 500 Hz square wave for ~2 s.
  // This helps verify wiring even if TIM4 PWM were misconfigured.
  HAL_TIM_PWM_Stop(&htim4, TIM_CHANNEL_1);
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  GPIO_InitStruct.Pin = BigSound_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
  HAL_GPIO_Init(BigSound_GPIO_Port, &GPIO_InitStruct);
  for (int i = 0; i < 2000; ++i) {
    HAL_GPIO_TogglePin(BigSound_GPIO_Port, BigSound_Pin);
    HAL_Delay(1); // toggle every 1 ms -> ~500 Hz tone
  }
  // Restore PB6 to TIM4_CH1 AF so normal Alarm_Set() PWM works
  HAL_TIM_MspPostInit(&htim4);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
